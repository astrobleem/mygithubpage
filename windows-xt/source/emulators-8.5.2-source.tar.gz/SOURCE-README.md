# Source and build materials for emulators 8.5.2

The unmodified source is pinned at the commits in SOURCE-MANIFEST.json.
DOSBox, DOSBox-X, libzip, Sokol and GL4ES source, headers, licenses, CMake,
TypeScript/Gulp build scripts and yarn.lock are included. These sources
correspond to the official emulators@8.5.2 npm package gitHead.
The runtime version suffix is a generated MD5 build identifier, not a Git SHA.

The npm publisher's .github/workflows/build.js.yml records Node 22 and
Emscripten SDK 5.0.2, CMake and Ninja. Install those general build tools
from their official vendors, restore npm/Yarn dependencies using yarn.lock,
source emsdk_env.sh, then build the browser targets wlibzip, wdosbox and
wdosbox-x using the CMake/targets/Gulp scripts. GL4ES is pinned separately
by CMakeLists.txt; its source is also included under native/gl4es.
No Sokol shader generation or benchmark/test guest is needed for these
three worker targets. Optional upstream game/demo media and Dhrystone's
prebuilt DOS4GW/EXE byte arrays are deliberately omitted. Do not build/run
those optional benchmarks or media tests from this archive.

The distributed WASM files are byte-identical official release assets.
The embedding JS and two worker footer error handlers are modified.
patches/patch-runtime.py reproduces those exact deployed edits from the
official npm package; patches/runtime-loader.js is the complete external
loader adaptation source. worker-errors.patch represents the footer edit.
loader-source-callsite.patch is the equivalent complete TypeScript loader
change; modified/ contains both modified source files. Use the supplied
external adapter with that source change. The deployed production bytes
are reproduced by the deterministic release-byte patch.

Full TypeScript source for all bundled embedding dependencies is preserved
in the official emulators.js.map, included as embedding-sources.json.
Rebuild output was not executed or compared bit-for-bit during release
review. Host checks compile WASM factory modules, instantiate libzip only,
and verify source/build input coverage and exact release-byte patches.

These materials and the modified runtime are distributed under their
included licenses, including GPLv2 for emulators/DOSBox/DOSBox-X. Individual
bundled library notices are preserved in their original source files.
